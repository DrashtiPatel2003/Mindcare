<footer>
    <p>&copy; 2025 Mental Health Project. All rights reserved.</p>
</footer>
</body>
</html>
