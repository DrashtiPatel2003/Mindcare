<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: index2.php");
    exit;
}
?>

<?php
// Include database connection
include '../includes/db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        /* General Body Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #fffaf5; /* Light pastel pink */
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: #ffe6f0; /* Pastel pink */
            padding: 20px;
            position: fixed;
            height: 100%;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h2 {
            color: #5a5a5a;
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 15px 0;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #5a5a5a;
            padding: 10px 15px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar ul li a:hover {
            background-color: #ff99c8; /* Bright pastel pink */
            color: white;
        }

        /* Main Content Styles */
        .main-content {
            margin-left: 270px; /* Sidebar width + margin */
            padding: 20px;
            background-color: #fff; /* White background */
            flex: 1;
        }

        .main-content header h1 {
            color: #5a5a5a;
            margin-bottom: 20px;
        }

        /* Dashboard Container Styles */
        .dashboard-container {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        /* Dashboard Card Styles */
        .dashboard-card {
            background-color: #ffe6f0; /* Pastel pink */
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            flex: 1;
            min-width: 250px;
            text-align: center;
        }

        .dashboard-card h3 {
            color: #5a5a5a;
            margin-bottom: 10px;
        }

        .dashboard-card p {
            color: #5a5a5a;
            margin-bottom: 15px;
        }

        .dashboard-card .btn {
            text-decoration: none;
            background-color: #ff99c8; /* Bright pastel pink */
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .dashboard-card .btn:hover {
            background-color: #cc6699; /* Darker pastel pink */
        }

        /* Footer Styles */
        footer {
            text-align: center;
            padding: 10px;
            background-color: #ffe6f0; /* Pastel pink */
            color: #5a5a5a;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 220px;
            }

            .dashboard-container {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <main>
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="view_messages.php">View Messages</a></li>
                <li><a href="manage_questions.php">Manage Questions</a></li>
                <li><a href="manage_users.php">Manage Users</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <header>
                <h1>&nbsp;&nbsp;&nbsp;&nbsp;Admin Dashboard</h1>
            </header>

            <section class="dashboard-container">
                <br>
                <!-- Dashboard Card 1: View User Messages -->
                <div class="dashboard-card">
                    <h3>View User Messages</h3>
                    <p>Read messages sent by users through the contact form.</p>
                    <a href="view_message.php" class="btn">Go to Messages</a>
                </div>

                <!-- Dashboard Card 2: Manage Questions -->
                <div class="dashboard-card">
                    <h3>Manage Questions</h3>
                    <p>Update and manage the questions for the mental health questionnaire.</p>
                    <a href="manage_questions.php" class="btn">Go to Questions</a>
                </div>

                <!-- Dashboard Card 3: Manage Users -->
                <div class="dashboard-card">
                    <h3>Manage Users</h3>
                    <p>Update user information and control access rights.</p>
                    <a href="manage_users.php" class="btn">Go to Users</a>
                </div>
                <!-- Dashboard Card 3: Manage Users -->
                <div class="dashboard-card">
                    <h3>User Mood</h3>
                    <p>Track User's mood.</p>
                    <a href="manage_mood.php" class="btn">Go to Users</a>
                </div>
            </section>
        </div>
    </main>

    <footer>
        <p>© 2025 Mental Health Project. All rights reserved.</p>
    </footer>
</body>
</html>
