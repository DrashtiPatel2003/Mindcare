function filterResources(type) {
  const allCards = document.querySelectorAll('.resource-card');

  allCards.forEach((card) => {
    if (type === 'all') {
      card.style.display = 'block';
    } else if (card.classList.contains(type)) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}
// Validation functions using Regex
document.addEventListener("DOMContentLoaded", function () {
  const passwordInput = document.getElementById("password");
  const confirmPasswordInput = document.getElementById("confirm-password");
  const passwordCriteria = document.getElementById("password-criteria");

  if (passwordInput) {
      passwordInput.addEventListener("input", () => {
          const value = passwordInput.value;
          const criteria = [
              /[A-Z]/.test(value), // Uppercase letter
              /[0-9]/.test(value), // Number
              /[!@#$%^&*]/.test(value), // Special character
              value.length >= 8, // Minimum length
          ];

          // Update criteria display
          const criteriaText = passwordCriteria.querySelectorAll("p");
          criteria.forEach((valid, index) => {
              criteriaText[index].style.color = valid ? "green" : "red";
          });
      });
  }

  if (confirmPasswordInput) {
      confirmPasswordInput.addEventListener("input", () => {
          const confirmPasswordError = document.getElementById("confirm-password-error");
          if (passwordInput.value !== confirmPasswordInput.value) {
              confirmPasswordError.textContent = "Passwords do not match.";
          } else {
              confirmPasswordError.textContent = "";
          }
      });
  }
});
document.getElementById('signup-form').addEventListener('submit', function(e) {
  e.preventDefault(); // Prevent default form submission

  const formData = new FormData(this);

  // Send form data to the PHP script
  fetch('signinsignup\signup.php', {
      method: 'POST',
      body: formData,
  })
  .then(response => response.json())
  .then(data => {
      const messageBox = document.getElementById('response-message');
      messageBox.style.display = 'block';

      if (data.status === 'success') {
          messageBox.textContent = data.message;
          messageBox.style.backgroundColor = 'green';
          messageBox.style.color = 'white';
          messageBox.style.transition = 'background-color 1s ease';

          setTimeout(() => {
              window.location.href = 'signinsignup\signin.html'; // Redirect to sign-in page after success
          }, 3000);
      } else {
          messageBox.textContent = data.message;
          messageBox.style.backgroundColor = 'red';
          messageBox.style.color = 'white';
          messageBox.style.transition = 'background-color 1s ease';
      }
  })
  .catch(error => {
      console.error('Error:', error);
  });
});

